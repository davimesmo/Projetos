#include <iomanip>
#include <sstream>
#include <iostream>
#include <vector>
#include <list>

using namespace std;
bool lexMenor(long long maskA, long long maskB) {
    if (maskA == maskB) return false;
    long long diff = maskA ^ maskB;
    long long lsb = diff & -diff;
    return (maskA & lsb);
}
void ladoB(int A, int B, vector<long long>&adj, vector<long long>&optTam, vector<long long>&optSol){
    long long maxMask = 1 << B;
    for(long long mask =0; mask < maxMask; mask++){
        bool valido = true;
        for(int i = 0; i < B; i++){
            if((mask >> i) & 1){
                long long vizinhos = adj[A + i];
                vizinhos = (vizinhos >> A);
                if(mask & vizinhos){
                    valido = false;
                    break;
                }
            }
        }
        if(valido){
            long long tam = mask;
            long long count = 0;
            while(tam > 0){
                count += (tam & 1);
                tam >>=1;
            }
            optTam[mask] = count;
            optSol[mask] = mask;
        }else{
            optTam[mask] = -1;
            optSol[mask] = 0;
        }
    }
    for(int i = 0; i < B; i++){
        for (long long mask = 0; mask < maxMask; mask++) {
            if ((mask >> i) & 1) {
                long long maskAnt = mask ^ (1LL << i);
                bool atualiza = false;
                if (optTam[maskAnt] > optTam[mask]) {
                    atualiza = true;
                } 
                else if (optTam[maskAnt] == optTam[mask]) {
                    if (lexMenor(optSol[maskAnt], optSol[mask])) {
                        atualiza = true;
                    }
                }
                if (atualiza) {
                    optTam[mask] = optTam[maskAnt];
                    optSol[mask] = optSol[maskAnt];
                }
            }
        }
    }
        
    
}
int main(){
    int n, m;
    cin >> n >> m;
    int A = n/2;
    int B = n - A;
    long long tamanho = 1 << B;
    vector<long long> adj(n, 0);
    int p1, p2;
    for(int i = 0; i < m; i++){
        cin >> p1 >> p2;
        adj[p1] = adj[p1] | (1LL << p2);
        adj[p2] = adj[p2] | (1LL << p1);
    }
    vector<long long> optTam(tamanho);
    vector<long long> optSol(tamanho);
    ladoB(A, B, adj, optTam, optSol);
    long long maxK = 0;
    long long melhorMask = 0;
    long long maxMaskA = (1LL << A);
    for(long long maskA = 0; maskA < maxMaskA; maskA++){
        bool valido = true;
        long long vizinhosB = 0;
        for(int i = 0; i< A; i++){
            if ((maskA >> i) & 1) {
                if (maskA & adj[i]) { 
                    valido = false;
                    break;
                }
                vizinhosB = vizinhosB | (adj[i] >> A);
            }
        }
        if(!valido) continue;
        long long livresB = ((1LL << B) - 1) & (~vizinhosB);
        long long tam = maskA;
        int count = 0;
        while(tam > 0){
                count += (tam & 1);
                tam >>=1;
            }
        long long tamTotal = count + optTam[livresB];
        long long solB = optSol[livresB];
        long long maskTotal = maskA | (solB << A);
        if(tamTotal > maxK){
            maxK = tamTotal;
            melhorMask = maskTotal;

        }else if(tamTotal == maxK){
            if(lexMenor(maskTotal, melhorMask)){
                melhorMask = maskTotal;
            }
        }
    }
    cout << maxK << endl;
    bool primeiro = true;
    for (int i = 0; i < n; i++) {
        if ((melhorMask >> i) & 1) {
            if (!primeiro) cout << " ";
            cout << i;
            primeiro = false;
        }
    }
    cout << endl;
    return 0;
}
