#include "ordenador.hpp"
#include <fstream>
#include <iostream>
#include <string>
using namespace std;

int main(int argc, char *argv[]) {
    if (argc < 2) {
        cerr << "Uso: " << argv[0] << " <arquivo de entrada>" << endl;
        return 1;
    }

    ifstream arquivo(argv[1]);
    if (!arquivo) {
        cerr << "Erro ao abrir o arquivo " << argv[1] << endl;
        return 1;
    }

    int seed;
    double limiarCusto, a, b, c;
    int tam;

    arquivo >> seed;
    arquivo >> limiarCusto >> a >> b >> c >> tam;
    OrdenadorUniversal<int> ordenador(tam, limiarCusto, a, b, c, seed, 3, 5);

    for (int i = 0; i < tam; i++) {
        arquivo >> ordenador.v[i];
        ordenador.original[i] = ordenador.v[i];
    }

    cout << "size " << tam
         << " seed " << seed
         << " breaks " << ordenador.numeroDeQuebras() << endl << endl;

    ordenador.resetaEstatisticas();
    ordenador.ordenadorUniversal();
    ordenador.determinaLimiarParticao();
    ordenador.determinaLimiarQuebras();

    return 0;
}
