#include "arvoreavl.hpp"
#include "evento.hpp"
#include "listainteiros.hpp"
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>

using namespace std;
//funcao para ordenar a saida, necessario para passar em uns testes
void ordenarResultados(ListaEncadeada<Evento *> &lista) {
  int n = lista.getTam();
  if (n < 2) {
    return;
  }

  for (int i = 1; i < n; i++) {
    for (int j = 1; j < n; j++) {

      Evento *atual = lista.getItem(j);
      Evento *proximo = lista.getItem(j + 1);

      if ((atual->getTimestamp() > proximo->getTimestamp()) ||
          (atual->getTimestamp() == proximo->getTimestamp() && atual->getIdPacote() > proximo->getIdPacote())) {
        lista.setItem(proximo, j);
        lista.setItem(atual, j + 1);
      }
    }
  }
}
//outra funcao para a saida ficar certa, dica do grupo, usei const pq tava dando erro sem
int prioridadeEvento(const string &tipo) {
  if (tipo == "EN")
    return 6;
  if (tipo == "TR")
    return 5;
  if (tipo == "UR")
    return 4;
  if (tipo == "RM")
    return 3;
  if (tipo == "AR")
    return 2;
  if (tipo == "RG")
    return 1;
  return 0;
}

/*

Assim como no TP2, achei que seria plausível utilizar a main para, além de parsear a entrada, efetuar as
consultas.

*/

int main(int argc, char *argv[]) {
  string nomeArquivo = argv[1];
  ifstream arquivoEntrada(nomeArquivo);
  if (!arquivoEntrada.is_open()) {
    cerr << "Erro: Nao foi possivel abrir o arquivo " <<  endl;
    return 1;
  }

  ListaEncadeada<string> linhas_da_entrada;
  string linha;
  while (getline(arquivoEntrada, linha)) {
      linhas_da_entrada.insereFinal(linha);
  }
  arquivoEntrada.close();

  // armazenamento principal para todos os ponteiros de evento, pra deletar depois
  ListaEncadeada<Evento *> baseDeEventos;

  // indice de pacotes: mapeia id para uma lista de ponteiros de evento
  ArvoreAVL<int, ListaEncadeada<Evento *> *> indicePacotes;

  // indice de clientes: mapeia nome para uma lista de IDs de pacotes
  ArvoreAVL<string, ListaEncadeada<int> *> indiceClientes;

  for (int i = 1; i <= linhas_da_entrada.getTam(); ++i) {
    string linha_atual = linhas_da_entrada.getItem(i);
    stringstream ss(linha_atual);

    int timestamp;
    string comando;
    ss >> timestamp >> comando;

    if (comando == "EV") {
      string tipoEvento;
      int idPacote;
      ss >> tipoEvento >> idPacote;

      string remetente = " ", destinatario = " ";
      int armazemOrig = -1, armazemDest = -1;

      if (tipoEvento == "RG") {
        ss >> remetente >> destinatario >> armazemOrig >> armazemDest;
      } else if (tipoEvento == "TR") {
        ss >> armazemOrig >> armazemDest;
      } else if (tipoEvento == "AR" || tipoEvento == "RM" || tipoEvento == "UR") {
        ss >> armazemOrig >> armazemDest;
      } else if (tipoEvento == "EN") {
        ss >> armazemDest;
      }

      // criar e armazenar o evento
      Evento *novoEvento = new Evento(timestamp, tipoEvento, idPacote, remetente, destinatario, armazemOrig, armazemDest, linha_atual);
      baseDeEventos.insereFinal(novoEvento);

      // atualizar o indice de pacotes
      ListaEncadeada<Evento *> **listaEventosPtr = indicePacotes.buscar(idPacote);
      if (listaEventosPtr == nullptr) {
        // pacote novo
        ListaEncadeada<Evento *> *novaLista = new ListaEncadeada<Evento *>();
        novaLista->insereFinal(novoEvento);
        indicePacotes.inserir(idPacote, novaLista);
      } else {
        // pacote já existe no índice
        (*listaEventosPtr)->insereFinal(novoEvento);
      }

      // se for um evento de registro, atualizar o índice de clientes
      if (tipoEvento == "RG") {
        // atualiza para o remetente
        ListaEncadeada<int> **listaPacotesRem = indiceClientes.buscar(remetente);
        if (listaPacotesRem == nullptr) {
          ListaEncadeada<int> *novaLista = new ListaEncadeada<int>();
          novaLista->insereFinal(idPacote);
          indiceClientes.inserir(remetente, novaLista);
        } else if (!(*listaPacotesRem)->pesquisa(idPacote)) {
          (*listaPacotesRem)->insereFinal(idPacote);
        }

        // atualiza para o destinatário
        ListaEncadeada<int> **listaPacotesDest = indiceClientes.buscar(destinatario);
        if (listaPacotesDest == nullptr) {
          ListaEncadeada<int> *novaLista = new ListaEncadeada<int>();
          novaLista->insereFinal(idPacote);
          indiceClientes.inserir(destinatario, novaLista);
        } else if (!(*listaPacotesDest)->pesquisa(idPacote)) {
          (*listaPacotesDest)->insereFinal(idPacote);
        }
      }

    } else if (comando == "PC") {
      int idPacote;
      ss >> idPacote;

      cout << setw(6) << setfill('0') << timestamp << " " << comando << " " << setw(3) << setfill('0') << idPacote << endl;
      ListaEncadeada<Evento *> resultados;
      ListaEncadeada<Evento *> **listaEventosPtr = indicePacotes.buscar(idPacote);
      // se achou eventos desse pacote
      if (listaEventosPtr != nullptr) {
        ListaEncadeada<Evento *> *listaEventos = *listaEventosPtr;
        for (int j = 1; j <= listaEventos->getTam(); ++j) {
          Evento *ev = listaEventos->getItem(j);
          //coloca na lista eventos até o timestamp
          if (ev->getTimestamp() <= timestamp) {
            resultados.insereFinal(ev);
          }
        }
      }
      cout << resultados.getTam() << endl;
      for (int j = 1; j <= resultados.getTam(); ++j) {
        cout << resultados.getItem(j)->getLinhaCompleta() << endl;
      }

    } else if (comando == "CL") {
      string nomeCliente;
      ss >> nomeCliente;

      cout << setw(6) << setfill('0') << timestamp << " " << comando << " " << nomeCliente << endl;
      ListaEncadeada<Evento *> resultados;
        //acha a lista de pacotes para o cliente
      ListaEncadeada<int> **listaPacotesPtr = indiceClientes.buscar(nomeCliente);
      if (listaPacotesPtr != nullptr) {
        ListaEncadeada<int> *listaPacotes = *listaPacotesPtr;
        for (int j = 1; j <= listaPacotes->getTam(); ++j) {
          int idPacote = listaPacotes->getItem(j);
          ListaEncadeada<Evento *> **listaEventosPtr = indicePacotes.buscar(idPacote);
          if (listaEventosPtr != nullptr) {
            ListaEncadeada<Evento *> *listaEventos = *listaEventosPtr;

            Evento *eventoRG = nullptr;
            Evento *eventoMaisRecente = nullptr;
            //encontra o evento RG e o evento mais recente até o tempo da consulta, para cada pacote do cliente
            for (int k = 1; k <= listaEventos->getTam(); ++k) {
              Evento *ev = listaEventos->getItem(k);
              //ignora eventos futuros
              if (ev->getTimestamp() > timestamp)
                continue; 

              if (ev->getTipo() == "RG") {
                eventoRG = ev;
              }
              if (eventoMaisRecente == nullptr) {
                eventoMaisRecente = ev;
              } else {
                if (ev->getTimestamp() > eventoMaisRecente->getTimestamp()) {
                  eventoMaisRecente = ev;
                }
                else if (ev->getTimestamp() == eventoMaisRecente->getTimestamp()) {
                    //desempate
                  if (prioridadeEvento(ev->getTipo()) > prioridadeEvento(eventoMaisRecente->getTipo())) {
                    eventoMaisRecente = ev;
                  }
                }
              }
            }
            //coloca na lista de resultados
            if (eventoRG != nullptr)
              resultados.insereFinal(eventoRG);
            if (eventoMaisRecente != nullptr && eventoMaisRecente != eventoRG) {
              resultados.insereFinal(eventoMaisRecente);
            }
          }
        }
      }
      //garante a ordem certa
      ordenarResultados(resultados);
      cout << resultados.getTam() << endl;
      for (int j = 1; j <= resultados.getTam(); ++j) {
        cout << resultados.getItem(j)->getLinhaCompleta() << endl;
      }
    }
  }

  for (int i = 1; i <= baseDeEventos.getTam(); ++i) {
    delete baseDeEventos.getItem(i);
  }
  ListaEncadeada<ListaEncadeada<Evento *> *> listasDeEventos;
  indicePacotes.obterTodosValores(listasDeEventos);
  for (int i = 1; i <= listasDeEventos.getTam(); ++i) {
    delete listasDeEventos.getItem(i);
  }

  ListaEncadeada<ListaEncadeada<int> *> listasDePacotes;
  indiceClientes.obterTodosValores(listasDePacotes);
  for (int i = 1; i <= listasDePacotes.getTam(); ++i) {
    delete listasDePacotes.getItem(i);
  }

  return 0;
}